-- phpMyAdmin SQL Dump
-- version 2.11.2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 10, 2017 at 05:01 AM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `lr`
--

-- --------------------------------------------------------

--
-- Table structure for table `lr_user`
--

CREATE TABLE `lr_user` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `username` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `password` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `lr_user`
--

INSERT INTO `lr_user` (`id`, `name`, `username`, `email`, `password`) VALUES
(1, 'Masud Parbhez', 'Parbhez', 'masud@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055'),
(2, 'Riyaz Uddin', 'Rana', 'rana@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055'),
(3, 'Ashraful islam', 'Shohag', 'shohag@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055'),
(4, 'Ahadul Islam', 'pavel', 'pavel.affb@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055');
